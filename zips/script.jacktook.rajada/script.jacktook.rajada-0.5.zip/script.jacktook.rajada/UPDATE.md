## Update Guide

### Add provider

1. add entry to providers.json (color MUST be `FFF14E13` if brazilian)
2. add provider icon to `.../providers/icons/` folder
3. use check_provider scripts to assert provider is working
4. update settings.xml
5. add entry to `README.md` of providers folder
