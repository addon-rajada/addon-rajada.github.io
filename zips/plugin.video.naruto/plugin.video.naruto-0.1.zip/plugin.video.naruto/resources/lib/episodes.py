# -*- coding: utf-8 -*-
# Copyright (C) 2024 gbchr

import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

# 1 to 4 (why?)
url_c = 'https://api.themoviedb.org/3/tv/46260/season/%s?api_key=bc96b19479c7db6c8ae805744d0bdfe2&language=pt-br'

# 1 to 20
url_s = 'https://api.themoviedb.org/3/tv/31910/season/%s?api_key=bc96b19479c7db6c8ae805744d0bdfe2&language=pt-br'

def get_request(url):
	try:
		try: response = requests.get(url)
		except requests.exceptions.SSLError:
			response = requests.get(url, verify=False)
	except requests.exceptions.ConnectionError: None

	if '200' in str(response): return response.json()
	elif 'Retry-After' in response.headers:
		throttleTime = response.headers['Retry-After']
		return get_request(url)
	else: return None

def parse(content):
	parsed = {}
	for r in content:
		for ep in r['episodes']:
			parsed[ep['episode_number']] = {
				"data": ep['air_date'],
				"imagem": 'https://image.tmdb.org/t/p/w780' + ep['still_path'],
				"nome": ep['name'],
				"sinopse": ep['overview'],
				"duracao": ep['runtime'],
				"nota": ep['vote_average'],
				"votos": ep['vote_count']
			}
	return parsed

def eps_classico():
	all = []
	with ThreadPoolExecutor(max_workers = 4) as executor:
		futures = [executor.submit(get_request, url = url_c % value) for value in range(1,5)]
		for f in as_completed(futures):
			result = f.result()
			all.append(result)
	return parse(all)

def eps_shippuden():
	all = []
	with ThreadPoolExecutor(max_workers = 20) as executor:
		futures = [executor.submit(get_request, url = url_s % value) for value in range(1,21)]
		for f in as_completed(futures):
			result = f.result()
			all.append(result)
	return parse(all)
