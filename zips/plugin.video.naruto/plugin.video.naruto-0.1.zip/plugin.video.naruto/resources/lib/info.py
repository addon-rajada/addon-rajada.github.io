# -*- coding: utf-8 -*-
# Copyright (C) 2024 gbchr

classico = [
	{
		'title': 'Prólogo - País das Ondas',
		'plot': 'Temporadas: 1\nEpisódios: 1 - 19',
		'sinopse': 'Este arco apresenta o protagonista Naruto Uzumaki e o mundo ninja em que vive, mostra a formação do Time Kakashi e finaliza com a missão ao País das Ondas',
		'img': 'c1-19.png'
	},
	{
		'title': 'Exames Chuunin',
		'plot': 'Temporadas: 1,2,3\nEpisódios: 20 - 67',
		'sinopse': 'Este arco mostra a ingressão do Time Kakashi para os Exames Chuunin e o funcionamento do evento, introduz outros personagens e times, como o resto dos Nove Novatos e Orochimaru, e demonstra o poder de vários ninjas e clãs da série',
		'img': 'c20-67.jpg'
	},
	{
		'title': 'Reportagem Especial! Ao Vivo da Floresta da Morte! O Jornal de Classe da Folha! (Filler)',
		'plot': 'Temporadas: 2\nEpisódios: 26',
		'sinopse': '',
		'img': 'c26.png',
		'color': 'palegreen'
	},
	
	{
		'title': 'Esmagamento de Konoha',
		'plot': 'Temporadas: 3,4\nEpisódios: 68 - 80',
		'sinopse': 'É um arco da série que mostra a tentativa de Orochimaru, junto com Sunagakure, em destruir Konohagakure',
		'img': 'c68-80.jpg'
	},
	{
		'title': 'Busca por Tsunade',
		'plot': 'Temporadas: 4\nEpisódios: 81 - 100',
		'sinopse': 'É um arco da série que mostra a primeira aparição da Akatsuki, bem como as tentativas concorrentes de Jiraiya e Orochimaru para recrutar Tsunade e o treinamento de Naruto para aprender o Rasengan',
		'img': 'c81-100.jpg'
	},
	{
		'title': 'Sequestrado! A Experiência de Naruto nas Fontes Termais (Filler)',
		'plot': 'Temporadas: 4\nEpisódios: 97',
		'sinopse': '',
		'img': 'c97.png',
		'color': 'crimson'
	},
	{
		'title': 'Quero Ver! Saber! Conferir! O Rosto do Kakashi-sensei (Filler)',
		'plot': 'Temporadas: 4\nEpisódios: 101',
		'sinopse': '',
		'img': 'c101.png',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Escolta no País do Chá (Filler)',
		'plot': 'Temporadas: 4,5\nEpisódios: 102 - 106',
		'sinopse': 'O arco consiste em Naruto, Sasuke e Sakura cumprir uma missão no País do Chá sobre ajudar Idate Morino a vencer uma corrida contra a Família Wagarashi no nome da Família Wasabi',
		'img': 'c102-106.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Recuperação de Sasuke',
		'plot': 'Temporadas: 5,6\nEpisódios: 107 - 135',
		'sinopse': 'Este arco mostra a primeira missão de Shikamaru Nara como chuunin, em que o objetivo é formar um time para impedir que Sasuke Uchiha desertasse de Konoha e chegasse nas mãos de Orochimaru, porém se deparam com o Quinteto do Som, mas logo são ajudados pelos Três Irmãos da Areia, enquanto isso, Naruto corre atrás de Sasuke para convencê-lo a voltar, mas a discussão acaba numa grande luta no Vale do Fim',
		'img': 'c107-135.jpg'
	},
	
	{
		'title': 'Missão de Investigação no País dos Campos de Arroz (Filler)',
		'plot': 'Temporadas: 6\nEpisódios: 136 - 141',
		'sinopse': 'Naruto, Sakura e Jiraiya, em uma missão, investigam o paradeiro de Orochimaru no País dos Campos de Arroz, mas se encontram com o clã Fuuma',
		'img': 'c136-141.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Rastreamento a Mizuki (Filler)',
		'plot': 'Temporadas: 6\nEpisódios: 142 - 147',
		'sinopse': 'Iruka, com a ajuda de Naruto e Tsubaki, tentam recapturar Mizuki e os Lendários Irmãos Estúpidos que escaparam do Centro de Vigilância Rigorosa de Konoha',
		'img': 'c142-147.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Busca ao Bikouchuu (Filler)',
		'plot': 'Temporadas: 6\nEpisódios: 148 - 151',
		'sinopse': 'Naruto e Time 8 partem para procurar pelo bikouchuu, na esperança de que ele possa levá-los até Sasuke, mas se encontram com o clã Kamizuru, que também estavam atrás do besouro',
		'img': 'c148-151.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Remoção da Família Kurosuki (Filler)',
		'plot': 'Temporadas: 6,7\nEpisódios: 152 - 157',
		'sinopse': 'Time Guy e Naruto recebem uma missão de escolta até o País dos Rios, mas descobrem que Raiga e a Família Kurosuki estão causando terror no local',
		'img': 'c152-157.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Siga-me! O Grande Desafio de Sobrevivência (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 158',
		'sinopse': 'Naruto é escolhido para liderar Konohamaru, Moegi e Udon num exercício de sobrevivência. Seu destino é o Rosto de Pedra de Warudakumi, no alto do Monte Takurami',
		'img': 'c158.png',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Captura a Gosunkugi (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 159 - 160',
		'sinopse': 'Naruto, Kiba e Hinata recebem uma missão para capturar Gosunkugi, mas no caminho se encontram com Sazanami e ajudam a limpar seu nome',
		'img': 'c159-160.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Chegam Visitantes - A Fera Verde? Carnívora? ...É Bem-vinda? (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 161',
		'sinopse': '',
		'img': 'c161.png',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Extermínio ao Guerreiro Amaldiçoado (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 162 - 167',
		'sinopse': 'Naruto, Neji e Tenten vão para o País dos Pássaros para lidarem com um misterioso fantasma',
		'img': 'c162-167.png',
		'color': 'crimson'
	},
	{
		'title': 'A Panela Ferve! Misturem, Amassem e Cozinhem!! (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 168',
		'sinopse': '',
		'img': 'c168.png',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Captura ao Kaima (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 169 - 173',
		'sinopse': 'Anko Mitarashi leva Naruto, Ino e Shino para o País do Mar para encontrarem informações sobre Orochimaru',
		'img': 'c169-173.png',
		'color': 'palegreen'
	},
	{
		'title': 'Não Acredito, To Certo! A Técnica das Celebridades: Kinton no Jutsu (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 174',
		'sinopse': '',
		'img': 'c174.png',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Escavação ao Tesouro Enterrado (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 175 - 176',
		'sinopse': 'Naruto, novamente, forma equipe com Kiba e Hinata, a fim de melhorarem o seu trabalho em equipe',
		'img': 'c175-176.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Oh!? Por Favor ♥ Senhor Carteiro (Filler)',
		'plot': 'Temporadas: 7\nEpisódios: 177',
		'sinopse': '',
		'img': 'c177.png',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Proteção à Estrela (Filler)',
		'plot': 'Temporadas: 7,8\nEpisódios: 178 - 183',
		'sinopse': 'Naruto e o Time Guy vão para Hoshigakure para ajudarem os moradores a proteger sua estrela sagrada',
		'img': 'c178-183.jpg',
		'color': 'crimson'
	},
	{
		'title': 'O Looongo Dia de Inuzuka Kiba (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 184',
		'sinopse': '',
		'img': 'c184.png',
		'color': 'crimson'
	},
	{
		'title': 'A Lenda da Folha Oculta - Onbaa Realmente Existiu!! (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 185',
		'sinopse': '',
		'img': 'c185.png',
		'color': 'palegreen'
	},
	{
		'title': 'Shino Rindo (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 186',
		'sinopse': '',
		'img': 'c186.png',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Escolta dos Comerciantes (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 187 - 191',
		'sinopse': 'Naruto, Hinata e Chōji vão para o País dos Vegetais para proteger alguns camelôs contra os Irmãos Criminosos',
		'img': 'c187-191.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Ino Grita! O Paraíso da Gordura! (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 192',
		'sinopse': '',
		'img': 'c192.png',
		'color': 'crimson'
	},
	{
		'title': 'Desafio Dojo Biba! A Juventude É Explosiva (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 193',
		'sinopse': '',
		'img': 'c193.png',
		'color': 'palegreen'
	},
	{
		'title': 'Grotesco - O Castelo Mau-Assombrado (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 194',
		'sinopse': '',
		'img': 'c194.png',
		'color': 'crimson'
	},
	{
		'title': 'Arco Terceira Grande Besta (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 195 - 196',
		'sinopse': 'Guy é forçado a lidar com a aparente tentativa de vingança de Yagura',
		'img': 'c195-196.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Recuperação das Plantas de Konoha (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 197 - 201',
		'sinopse': 'Os 11 de Konoha tentam impedir que Gennō destrua Konoha',
		'img': 'c197-201.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'As 5 Melhores Batalhas Ninjas entre Suor e Lágrimas! (Filler)',
		'plot': 'Temporadas: 8\nEpisódios: 202',
		'sinopse': '',
		'img': 'c202.png',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Resgate de Yakumo Kurama (Filler)',
		'plot': 'Temporadas: 9\nEpisódios: 203 - 207',
		'sinopse': 'Kurenai deixa temporariamente o Time 8 para cuidar de alguns negócios do passado relacionados com Yakumo Kurama',
		'img': 'c203-207.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Artefato Raro - O Peso das Belezas da Natureza (Filler)',
		'plot': 'Temporadas: 9\nEpisódios: 208',
		'sinopse': '',
		'img': 'c208.png',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Escolta de Gantetsu (Filler)',
		'plot': 'Temporadas: 9\nEpisódios: 209 - 212',
		'sinopse': 'Naruto, Rock Lee e Sakura ajudam a transferir um membro dos Shinobazu para a prisão',
		'img': 'c209-212.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Busca pela Memória de Menma (Filler)',
		'plot': 'Temporadas: 9\nEpisódios: 213 - 215',
		'sinopse': 'Naruto ajuda Menma a recuperar sua memória',
		'img': 'c213-215.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Apoio a Sunagakure (Filler)',
		'plot': 'Temporadas: 9\nEpisódios: 216 - 220',
		'sinopse': 'Os 11 de Konoha vão para Sunagakure para ajudar a resgatar Matsuri das mãos dos Quatro Homens dos Símbolos Celestiais',
		'img': 'c216-220.jpg',
		'color': 'palegreen'
	}
]

pular_classico = [97, 136, 137, 138, 139, 140, 141, 148, 149, 150, 151, 159, 160, 162, 163, 164, 165, 166, 167, 168, 174, 175, 176, 177, 178, 179, 180, 181, 182, 183, 184, 192, 194, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212]

nao_pular_classico = [26,*range(101,107),*range(142,148),*range(152,159),161,*range(169,174),*range(185,192),193,*range(195,202),*range(213,221)]

shippuden = [
	{
		'title': 'Missão de Resgate do Kazekage',
		'plot': 'Temporadas: 1,2\nEpisódios: 1 - 27 & 29 - 32',
		'sinopse': 'Este arco mostra o resgate do Quinto Kazekage das mãos da Akatsuki',
		'img': 's1-27.jpg'
	},
	{
		'title': 'As Feras Ressuscitadas!',
		'plot': 'Temporadas: 1\nEpisódios: 28',
		'sinopse': '',
		'img': 's28.png',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Reconhecimento na Ponte Tenchi',
		'plot': 'Temporadas: 2\nEpisódios: 33 - 53',
		'sinopse': 'Este arco mostra a missão do Time Kakashi para a Ponte Tenchi para encontrar Sasuke Uchiha',
		'img': 's33-53.jpg'
	},
	{
		'title': 'Doze Guardiões Ninja (Filler)',
		'plot': 'Temporadas: 3\nEpisódios: 54 - 71',
		'sinopse': 'O arco apresenta os Doze Guardiões Ninja e o treinamento de Naruto para controlar o vento através da introdução de um menino chamado Sora',
		'img': 's54-71.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Missão de Repressão da Akatsuki',
		'plot': 'Temporadas: 3,4\nEpisódios: 72 - 88',
		'sinopse': 'Este arco mostra a luta de Konoha contra Hidan e Kakuzu da Akatsuki',
		'img': 's72-88.jpg'
	},
	{
		'title': 'Aparição do Três-Caudas (Filler)',
		'plot': 'Temporadas: 4,5\nEpisódios: 89 - 112',
		'sinopse': 'Mostra os esforços da Akatsuki, Konoha e o Time Guren para capturar o Três-Caudas',
		'img': 's89-112.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Missão de Perseguição a Itachi',
		'plot': 'Temporadas: 5\nEpisódios: 113 - 118 & 121 - 123',
		'sinopse': 'Este arco mostra as tentativas separadas de Sasuke Uchiha e Naruto Uzumaki para encontrar Itachi Uchiha',
		'img': 's113-118.jpg'
	},
	{
		'title': 'Kakashi Gaiden',
		'plot': 'Temporadas: 5\nEpisódios: 119 - 120',
		'sinopse': 'Este arco explora como Kakashi Hatake ganhou o seu Sharingan',
		'img': 's119-120.png'
	},
	{
		'title': 'O Conto de Jiraiya, o Destemido',
		'plot': 'Temporadas: 5,6\nEpisódios: 124 - 133',
		'sinopse': 'Este arco mostra a investigação de Jiraiya para descobrir a identidade de Pain',
		'img': 's124-133.jpg'
	},
	{
		'title': 'Predestinada Batalha entre Irmãos',
		'plot': 'Temporadas: 6\nEpisódios: 134 - 143',
		'sinopse': 'Este arco mostra a batalha entre Sasuke Uchiha e seu irmão Itachi',
		'img': 's134-143.jpg'
	},
	{
		'title': 'Liberação do Seis-Caudas (Filler)',
		'plot': 'Temporadas: 6\nEpisódios: 144 - 151',
		'sinopse': 'Mostra o laço entre mestre e aluno chamados Utakata, o jinchuuriki do Seis-Caudas, e sua aluna Hotaru',
		'img': 's144-151.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Ataque de Pain',
		'plot': 'Temporadas: 6,7\nEpisódios: 152 - 169 & 172 - 175',
		'sinopse': 'Este arco mostra o ataque de Pain em Konoha para encontrar Naruto Uzumaki',
		'img': 's152-169.jpg'
	},
	{
		'title': 'Uma Grande Aventura! A busca Pelo Legado do Quarto!',
		'plot': 'Temporadas: 7\nEpisódios: 170 - 171',
		'sinopse': '',
		'img': 's170-171.png',
		'color': 'crimson'
	},
	{
		'title': 'Arco do Passado: O Lugar de Konoha (Filler)',
		'plot': 'Temporadas: 7,8\nEpisódios: 176 - 196',
		'sinopse': 'Este arco mostra vários flashbacks de diferentes personagens, como Iruka se lembrando da vez em que ele conheceu Naruto e Kakashi se lembrando quando ele foi apontado como líder do Time 7 a partir de sua perspectiva',
		'img': 's176-196.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Reunião dos Cinco Kage',
		'plot': 'Temporadas: 8,9\nEpisódios: 197 - 215',
		'sinopse': ' Este arco mostra a convocação de uma Reunião Kage para discutir sobre como lidar com a Akatsuki',
		'img': 's197-215.jpg'
	},
	{
		'title': 'Quarta Guerra Mundial Shinobi: Contagem Regressiva',
		'plot': 'Temporadas: 9,10\nEpisódios: 216 - 222 & 243 - 255',
		'sinopse': 'Este arco mostra os preparativos para a Quarta Guerra Mundial Shinobi por todas as partes em conflito',
		'img': 's216-222.jpg'
	},
	{
		'title': 'Vida Paradisíaca em um Barco (Filler)',
		'plot': 'Temporadas: 9,10\nEpisódios: 223 - 242',
		'sinopse': 'Este arco mostra Naruto e sua equipe em sua viagem para o País do Relâmpago por mar, para confiná-lo da Akatsuki durante a Quarta Guerra Mundial Shinobi, bem como o desenvolvimento dos membros dos 11 de Konoha',
		'img': 's223-242.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Episódios Filler',
		'plot': 'Temporadas: 11\nEpisódios: 257 - 260',
		'sinopse': '',
		'img': 's257-260.png',
		'color': 'crimson'
	},
	{
		'title': 'Quarta Guerra Mundial Shinobi: Confronto',
		'plot': 'Temporadas: 10,11,12,13\nEpisódios: 256 & 261 - 270 & 272 - 278 & 282 - 289 & 296 - 310 & 312 - 321',
		'sinopse': 'Este arco mostra o início da Quarta Guerra Mundial Shinobi, especificamente a batalha contra a Reencarnação nas Terras Impuras',
		'img': 's261-270.jpg'
	},
	{
		'title': 'A Estrada de Sakura',
		'plot': 'Temporadas: 11\nEpisódios: 271',
		'sinopse': '',
		'img': 's271.png',
		'color': 'crimson'
	},
	{
		'title': 'Episódios Filler',
		'plot': 'Temporadas: 11\nEpisódios: 279 - 281',
		'sinopse': '',
		'img': 's279-281.png',
		'color': 'crimson'
	},
	{
		'title': 'Força (Filler)',
		'plot': 'Temporadas: 12\nEpisódios: 290 - 295',
		'sinopse': 'Este arco se passa depois de um curto período de tempo após a Reunião dos Cinco Kage em meio à ameaça de uma Quarta Guerra Mundial Shinobi, o Time Kakashi é enviado em uma missão para investigar o massacre na Vila Tonika realizado por Kabuto Yakushi e seus shinobi reanimados, que estão à procura de um tesouro composto de grande Força',
		'img': 's290-295.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Prólogo de Road to Ninja (Filler)',
		'plot': 'Temporadas: 13\nEpisódios: 311',
		'sinopse': '',
		'img': 's311.png',
		'color': 'palegreen'
	},
	{
		'title': 'Quarta Guerra Mundial Shinobi: Clímax',
		'plot': 'Temporadas: 13,14,15\nEpisódios: 322 - 348 & 362 - 375',
		'sinopse': 'Este arco mostra a luta das Forças Aliadas Shinobi contra Kabuto Yakushi, Tobi e Madara Uchiha, como parte do curso da Quarta Guerra Mundial Shinobi',
		'img': 's322-348.jpg'
	},
	{
		'title': 'Kakashi Anbu: O Shinobi Que Vive Na Escuridão (Filler)',
		'plot': 'Temporadas: 14,15\nEpisódios: 349 - 361',
		'sinopse': 'O arco mostra o período em que Kakashi Hatake atuava na Anbu, ao mesmo tempo, explorando as origens de outros, como Yamato e Itachi Uchiha',
		'img': 's349-361.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Instruções Para Capturar a Nove Caudas',
		'plot': 'Temporadas: 15\nEpisódios: 376 - 377',
		'sinopse': '',
		'img': 's376-377.png',
		'color': 'crimson'
	},
	{
		'title': 'Nascimento do Jinchūriki do Dez-Caudas',
		'plot': 'Temporadas: 15,16,17\nEpisódios: 378 - 388 & 391 - 393 & 414 - 415 & 417 - 421 & 424 - 427',
		'sinopse': 'Este arco mostra Obito Uchiha e Madara Uchiha se tornando o jinchuuriki do Dez-Caudas',
		'img': 's378-388.jpg'
	},
	{
		'title': 'A adorada irmã mais velha (Filler)',
		'plot': 'Temporadas: 16\nEpisódios: 389 - 390',
		'sinopse': '',
		'img': 's389-390.png',
		'color': 'palegreen'
	},
	{
		'title': 'Seguindo os Passos de Naruto: Os Caminhos dos Amigos (Filler)',
		'plot': 'Temporadas: 16,17\nEpisódios: 394 - 413',
		'sinopse': 'Este arco enfoca no segundo Exames Chuunin que ocorreram após a deserção de Sasuke Uchiha para Otogakure e a saída de Naruto Uzumaki para treinar com Jiraiya',
		'img': 's394-413.png',
		'color': 'crimson'
	},
	{
		'title': 'A Formação do Time Minato',
		'plot': 'Temporadas: 17\nEpisódios: 416',
		'sinopse': '',
		'img': 's416.png',
		'color': 'crimson'
	},
	{
		'title': 'Aqueles que herdarão',
		'plot': 'Temporadas: 17\nEpisódios: 422 - 423',
		'sinopse': '',
		'img': 's422-423.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Ataque de Kaguya Ootsutsuki (Filler)',
		'plot': 'Temporadas: 17\nEpisódios: 428 - 431',
		'sinopse': '',
		'img': 's428-431.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Manual de Instruções de Jiraiya: O Conto de Naruto, o Galante (Filler)',
		'plot': 'Temporadas: 18\nEpisódios: 432 - 450',
		'sinopse': 'Este arco se foca em um romance histórico escrito por Jiraiya no sonho de Tsunade no Tsukuyomi Infinito, em que aspectos fundamentais da vida de Naruto são diferentes',
		'img': 's432-450.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Livro Itachi Shinden: Luz e Escuridão (Filler)',
		'plot': 'Temporadas: 18\nEpisódios: 451 - 458',
		'sinopse': 'Este arco é uma adaptação em anime de duas novelas de Naruto Shinden que se focam sobre o início da vida de Itachi',
		'img': 's451-458.jpg',
		'color': 'palegreen'
	},
	{
		'title': 'Ataque de Kaguya Ootsutsuki',
		'plot': 'Temporadas: 19\nEpisódios: 459 - 479',
		'sinopse': 'Este arco mostra a tentativa de Kaguya Ootsutsuki em dominar o mundo',
		'img': 's459-479.jpg'
	},
	{
		'title': 'Arco do Período Juvenil (Filler)',
		'plot': 'Temporadas: 20\nEpisódios: 480 - 483',
		'sinopse': 'Ele consiste em uma Parte A e uma Parte B para dois personagens em um evento de suas memórias passadas em cada episódio',
		'img': 's480-483.jpg',
		'color': 'crimson'
	},
	{
		'title': 'Sasuke Shinden: Livro da Alvorada',
		'plot': 'Temporadas: 20\nEpisódios: 484 - 488',
		'sinopse': 'Este arco é uma adaptação anime da novela Sasuke Shinden: Alvorada da série Naruto Shinden, que se concentra na vida de Sasuke após a Quarta Guerra Mundial Shinobi',
		'img': 's484-488.jpg'
	},
	{
		'title': 'Shikamaru Hiden: Uma Nuvem se Acumulando na Escuridão do Silêncio',
		'plot': 'Temporadas: 20\nEpisódios: 489 - 493',
		'sinopse': 'Este arco é uma adaptação anime da novela Shikamaru Hiden: A Nuvem que Paira no Silêncio da Escuridão da série Naruto Shinden, que se concentra na vida de Shikamaru após a Quarta Guerra Mundial Shinobi',
		'img': 's489-493.jpg'
	},
	{
		'title': 'Konoha Hiden: O Dia Perfeito para um Casamento',
		'plot': 'Temporadas: 20\nEpisódios: 494 - 500',
		'sinopse': 'Este arco é uma adaptação anime da novela Konoha Hiden: Um Dia Perfeito para se Casar da série Naruto Hiden, que se concentra no casamento de Naruto e Hinata',
		'img': 's494-500.jpg'
	}
]

pular_shippuden = [28,*range(89,113),170,171,*range(223,243),*range(257,261),271,*range(279,282),376,377,*range(394,414),416,422,423,*range(428,451),*range(480,484)]

nao_pular_shippuden_original = [*range(54,72),*range(144,152),*range(176,197),*range(290,296),311,*range(349,362),*range(389,391),*range(451,459)          ]
nao_pular_shippuden = nao_pular_shippuden_original + [*range(303,321),417,427]


