# -*- coding: utf-8 -*-
# Copyright (C) 2024 gbchr

import requests
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

def get_request(url):
	try:
		try: response = requests.get(url)
		except requests.exceptions.SSLError:
			response = requests.get(url, verify=False)
	except requests.exceptions.ConnectionError: None

	if '200' in str(response): return response.text
	elif 'Retry-After' in response.headers:
		throttleTime = response.headers['Retry-After']
		return get_request(url)
	else: return None

def get_links_classico_dub():
	base_url = 'https://www.dattebane.com/pagina/Naruto Dublado HBO Download Lista Links'
	result = get_request(base_url)
	matches = re.findall(r'<li>(.*FHD.mp4)', result)
	name = 'Episódio %s'
	links = []
	for item in matches:
		number_match = re.findall(r'\s([0-9]{3})\s', item)
		number = int(number_match[0])
		links.append({
			'number': number,
			'name': name % (str(number)),
			'link': item.replace('download', 'stream').replace(' ', '%20')
		})
	return links

def get_links_classico_leg():
	base_url = 'http://www.dattebane.com/pagina/Naruto Classico Download Lista Links'
	result = get_request(base_url)
	matches = re.findall(r'<li>(.*MD.mp4)', result)
	name = 'Episódio %s'
	links = []
	for item in matches:
		try:
			number_match = re.findall(r'\s([0-9]{3})\s', item)
			number = int(number_match[0])
			links.append({
				'number': number,
				'name': name % (str(number)),
				'link': item.replace('download', 'stream').replace(' ', '%20')
			})
		except:
			try: # special case for multi episode files
				number = item.split()[-2]
				links.append({
					'number': int(number[:3]),
					'name': name % (str(number)),
					'link': item.replace('download', 'stream').replace(' ', '%20')
				})
			except: pass
	return links

def get_links_shippuden_dub():
	base_url = 'https://www.dattebane.com/pagina/Naruto Shippuuden Dublado Download Lista Links'
	result = get_request(base_url)
	matches = re.findall(r'<li>(.*HD MQP.mp4)', result)
	name = 'Episódio %s'
	links = []
	for item in matches:
		number_match = re.findall(r'\s([0-9]{3})\s', item)
		number = int(number_match[0])
		if number > 112: break
		links.append({
			'number': number,
			'name': name % (str(number)),
			'link': item.replace('download', 'stream').replace(' ', '%20')
		})
	return links

def get_links_shippuden_leg():
	base_url = 'http://www.dattebane.com/pagina/Naruto Shippuuden Download Lista Links'
	result = get_request(base_url)
	matches = re.findall(r'<li>(.*HD.mp4)', result)
	name = 'Episódio %s'
	links = []
	for item in matches:
		number_match = re.findall(r'\s([0-9]{3})\s', item)
		number = int(number_match[0])
		links.append({
			'number': number,
			'name': name % (str(number)),
			'link': item.replace('download', 'stream').replace(' ', '%20')
		})
	return links

def get_links_ovas():
	url = 'https://www.dattebane.com/OVAS/Naruto OVA/%s'
	eps = ['001', '002', '003', '004', '005', '006', '007', '008', '009', '010', '011']
	all = []
	with ThreadPoolExecutor(max_workers = 11) as executor:
		futures = [executor.submit(get_request, url = url % ep) for ep in eps]
		for f in as_completed(futures):
			result = f.result()
			name = re.findall(r'(Naruto OVA.*)<', result)
			links = re.findall(r'//(.*.mp4)', result)
			image = re.findall(r'//(.*/imagem/OVAS/.*.jpg)', result)
			all.append({
				"name": name[0],
				"link": 'https://' + links[0].replace('download', 'stream').replace(' ', '%20'),
				"image": 'https://' + image[0]
			})
	return sorted(all, key = lambda x: x['name'], reverse=False)
