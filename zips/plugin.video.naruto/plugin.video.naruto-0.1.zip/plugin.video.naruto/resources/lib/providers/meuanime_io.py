
def get_links_classico_dub():
	base_url = 'https://ns5009586.ip-15-235-14.net/Animes/N/naruto-classico-dublado/%s.MP4'
	name = 'Episódio %s'
	links = []

	for i in range(1,10):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % ("0" + str(i))
		})
	
	for i in range(10,100):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})

	for i in range(100,221):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})
	
	return links

def get_links_shippuden_dub():
	base_url = 'https://ns5009586.ip-15-235-14.net/Animes/N/naruto-shippuuden-dublado/%s.mp4'
	name = 'Episódio %s'
	links = []

	for i in range(1,10):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % ("0" + str(i))
		})
	
	for i in range(10,100):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})

	for i in range(100,113):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})
	
	return links
