
def get_links_shippuden_leg():
	base_url = 'https://mangas.cloud/Animes/Letra-N/Naruto Shippuden/%s.mp4'
	name = 'Episódio %s'
	links = []

	for i in range(1,10):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % ("0" + str(i))
		})
	
	for i in range(10,100):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})

	for i in range(100,501):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})
	
	return links

def get_links_classico_leg():
	base_url = 'https://animeq.xyz/Animes/Letra-N/Naruto/%s.mp4'
	name = 'Episódio %s'
	links = []

	for i in range(1,10):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % ("0" + str(i))
		})
	
	for i in range(10,100):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})

	for i in range(100,221):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})

	return links

def get_links_classico_dub():
	base_url = 'https://mangas.cloud//Animes/Letra-N/Naruto Classico Dublado/%s.mp4'
	name = 'Episódio %s'
	links = []

	for i in range(1,10):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % ("00" + str(i))
		})
	
	for i in range(10,100):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % ("0" + str(i))
		})

	for i in range(100,221):
		links.append({
			'number': i,
			'name': name % (str(i)),
			'link': base_url % (str(i))
		})
	
	return links
	
