# -*- coding: utf-8 -*-

from resources.lib import utils
from kodi_six import xbmc, xbmcgui, xbmcvfs, xbmcaddon
import time

addonInfo = xbmcaddon.Addon().getAddonInfo
addonPath = xbmcvfs.translatePath(addonInfo('path'))

class Service():

    WINDOW = xbmcgui.Window(10000)

    def __init__(self, *args):
        addonName = 'Naruto Skip Intro'
        self.skipped = False

    def ServiceEntryPoint(self):
        monitor = xbmc.Monitor()

        while not monitor.abortRequested():
            # check every 5 sec
            if monitor.waitForAbort(5):
                # Abort was requested while waiting. We should exit
                break
            if xbmc.Player().isPlaying():
                try:
                    playTime = xbmc.Player().getTime()

                    totalTime = xbmc.Player().getTotalTime()

					
                    current = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
                    #utils.notify('p ' + current)
                    #if current.startswith('plugin://plugin.video.naruto'):
                    if current.startswith('Naruto'):

                    #self.currentShow = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
                    #if self.currentShow: 
                        
                    #    if playTime > 250: self.skipped = True
                        if playTime > 250: self.skipped = True
                    #    if self.skipped == False: self.SkipIntro(self.currentShow)
                        if self.skipped == False: self.SkipIntro()
                    #print(("CURRENT SHOW PLAYER", currentShow, playTime))
                except:pass
            else: self.skipped = False
                
    def SkipIntro(self, tvshow = ''):
        try:
            if not xbmc.Player().isPlayingVideo(): raise Exception() 
            
            time.sleep(2)
            timeNow = xbmc.Player().getTime()
            
            #Dialog = CustomDialog('script-dialog.xml', addonPath, show=tvshow)
            Dialog = CustomDialog('skip-intro.xml', addonPath, show=tvshow)
            Dialog.doModal()
            self.skipped = True
            del Dialog  
            
        except:pass

OK_BUTTON = 201
NEW_BUTTON = 202
DISABLE_BUTTON = 210
ACTION_PREVIOUS_MENU = 10
ACTION_BACK = 92
INSTRUCTION_LABEL = 203
AUTHCODE_LABEL = 204
WARNING_LABEL = 205
CENTER_Y = 6
CENTER_X = 2

class CustomDialog(xbmcgui.WindowXMLDialog):

    def __init__(self, xmlFile, resourcePath, show):
        self.tvshow = show

    def onInit(self):
        instuction = ''
        self.skipValue = 87 # int(getSkip(self.tvshow))
        skipLabel = 'Pular 90 segundos' #'SKIP INTRO: %s' % self.skipValue
        skipButton = self.getControl(OK_BUTTON)
        #skipButton.setLabel(skipLabel)
        
    def onAction(self, action):
        if action == ACTION_PREVIOUS_MENU or action == ACTION_BACK:
            self.close()

    def onControl(self, control):
        pass

    def onFocus(self, control):
        pass

    def onClick(self, control):
        print(('onClick: %s' % (control)))

        if control == OK_BUTTON:
            timeNow = xbmc.Player().getTime()
            skipTotal = int(timeNow) + int(self.skipValue)
            time.sleep(1) # workaround
            xbmc.Player().seekTime(int(skipTotal))
            time.sleep(2) # workaround

        if control in [OK_BUTTON, NEW_BUTTON, DISABLE_BUTTON]:
            self.close()
            
Service().ServiceEntryPoint()
