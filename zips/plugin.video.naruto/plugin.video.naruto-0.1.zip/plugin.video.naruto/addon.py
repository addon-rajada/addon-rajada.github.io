# -*- coding: utf-8 -*-
# Copyright (C) 2024 gbchr

from resources.lib import routing, utils, torrent, info, episodes
from resources.lib.providers import animeq_blog, meuanime_io, dattebane_com
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import re

plugin = routing.Plugin()

welcome_label = 'Bem-vindo ao Year Explorer'
welcome_plot = 'Necessário Elementum e Rajada para realizar busca dos Torrents\n\nContato pelo email:\naddon.rajada@proton.me'

def list_episodes(function, skip, not_skip, imdb, tmdb, fanart_source):
	ep_data = None
	if 'classico' in fanart_source: ep_data = episodes.eps_classico()
	if 'shippuden' in fanart_source: ep_data = episodes.eps_shippuden()
	
	for item in function():
		# episode info
		ep_info = ep_data[item['number']]
		ep_plot = 'Nota: %s (%s votos)\n\n%s' % (ep_info['nota'], ep_info['votos'], ep_info['sinopse'])
		item['name'] = item['name'] + ' - ' + ep_info['nome']
		# title color
		new_title = None
		for ep in skip:
			if re.search(r'\b' + str(ep) + r'\b', item['name']):
				new_title = utils.colorful(item['name'], 'crimson')
		for ep in not_skip:
			if re.search(r'\b' + str(ep) + r'\b', item['name']):
				new_title = utils.colorful(item['name'], 'palegreen')
		if new_title == None:
			new_title = utils.colorful(item['name'], 'white')
		# create item
		utils.createItem(item['link'], new_title, imdb = imdb, tmdb = tmdb, fanart = fanart_source,
					 	 plot = ep_plot, image = ep_info['imagem'], datetime = ep_info['data'], duration = ep_info['duracao'])

@plugin.route('/')
def index():
	utils.createFolder(classico, 'Clássico (2002 - 2007)', ['index'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
	utils.createFolder(shippuden, 'Shippuden (2007 - 2017)', ['index'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
	utils.set_view('widelist')
	utils.endDirectory()


@plugin.route('/classico/<section>')
def classico(section):

	if section == 'index':
		utils.createFolder(classico, 'Arcos', ['arcos'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		utils.createFolder(classico, 'Episódios (Torrent)', ['episodios_torrent'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		utils.createFolder(classico, 'Episódios Dublados (Link Direto - Provedor 1)', ['episodios_dub_fonte1'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		utils.createFolder(classico, 'Episódios Dublados (Link Direto - Provedor 2)', ['episodios_dub_fonte2'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		# provider 3 not working 11.04.24
		#utils.createFolder(classico, 'Episódios Dublados (Link Direto - Provedor 3)', ['episodios_dub_fonte3'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		utils.createFolder(classico, 'Episódios Legendados (Link Direto - Provedor 2)', ['episodios_leg_fonte2'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		utils.createFolder(classico, 'Filmes', ['filmes'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)
		utils.createFolder(classico, 'OVAs', ['ovas'], 'icon.jpg', '', 'icon.jpg', utils.fanart_classico)

	if section == 'arcos':
		for item in info.classico:
			color = item['color'] if 'color' in item.keys() else None
			utils.createVisualItem(item['title'], item['plot'] + '\n\n' + item['sinopse'], item['img'], utils.fanart_classico, color)

	if section == 'episodios_torrent':
		for item in torrent.classico:
			utils.createItem('plugin://plugin.video.elementum/play?uri=' + item[1], item[0], imdb = 'tt0409591', tmdb = '46260', fanart = utils.fanart_classico)

	if section == 'episodios_dub_fonte1':
		list_episodes(animeq_blog.get_links_classico_dub, info.pular_classico, info.nao_pular_classico, 'tt0409591', '46260', utils.fanart_classico)

	if section == 'episodios_dub_fonte2':
		list_episodes(dattebane_com.get_links_classico_dub, info.pular_classico, info.nao_pular_classico, 'tt0409591', '46260', utils.fanart_classico)

	if section == 'episodios_dub_fonte3':
		list_episodes(meuanime_io.get_links_classico_dub, info.pular_classico, info.nao_pular_classico, 'tt0409591', '46260', utils.fanart_classico)

	if section == 'episodios_leg_fonte1':
		list_episodes(animeq_blog.get_links_classico_leg, info.pular_classico, info.nao_pular_classico, 'tt0409591', '46260', utils.fanart_classico)

	if section == 'episodios_leg_fonte2':
		list_episodes(dattebane_com.get_links_classico_leg, info.pular_classico, info.nao_pular_classico, 'tt0409591', '46260', utils.fanart_classico)
	
	if section == 'filmes':
		for item in torrent.filmes_classico:
			utils.createItem('plugin://plugin.video.elementum/play?uri=' + item[1], item[0], imdb = 'tt0409591', tmdb = '46260', fanart = utils.fanart_classico)
	
	if section == 'ovas':
		for item in dattebane_com.get_links_ovas():
			utils.createItem(item['link'], item['name'], imdb = 'tt0409591', tmdb = '46260', fanart = utils.fanart_classico, image = item['image'])

	#utils.createItem(elementum,
	#					item['titulo'],
	#					image = item['imagem'],
	#					plot = item['sinopse'],
	#					fanart = item['background'],
	#					current_year = year,
	#					id = item['tmdb'],
	#					mediatype = item['tipo'],
	#					real_title_search = utils.elementum_url(item['metodo_busca'], item['titulo_original'], year, item['tmdb']) )
	
	utils.endDirectory()


@plugin.route('/shippuden/<section>')
def shippuden(section):

	if section == 'index':
		utils.createFolder(shippuden, 'Arcos', ['arcos'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		utils.createFolder(shippuden, 'Episódios (Torrent)', ['episodios_torrent'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		utils.createFolder(shippuden, 'Episódios Dublados (Link Direto - Provedor 2)', ['episodios_dub_fonte2'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		# provider 3 not working 11.04.24
		#utils.createFolder(shippuden, 'Episódios Dublados (Link Direto - Provedor 3)', ['episodios_dub_fonte3'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		utils.createFolder(shippuden, 'Episódios Legendados (Link Direto - Provedor 1)', ['episodios_leg_fonte1'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		utils.createFolder(shippuden, 'Episódios Legendados (Link Direto - Provedor 2)', ['episodios_leg_fonte2'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		utils.createFolder(shippuden, 'Filmes', ['filmes'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)
		utils.createFolder(shippuden, 'OVAs', ['ovas'], 'icon.jpg', '', 'icon.jpg', utils.fanart_shippuden)

	if section == 'arcos':
		for item in info.shippuden:
			color = item['color'] if 'color' in item.keys() else None
			utils.createVisualItem(item['title'], item['plot'] + '\n\n' + item['sinopse'], item['img'], utils.fanart_shippuden, color)

	if section == 'episodios_torrent':
		for item in torrent.shippuden:
			utils.createItem('plugin://plugin.video.elementum/play?uri=' + item[1], item[0], imdb = 'tt0988824', tmdb = '31910', fanart = utils.fanart_shippuden)

	if section == 'episodios_dub_fonte2':
		list_episodes(dattebane_com.get_links_shippuden_dub, info.pular_shippuden, info.nao_pular_shippuden, 'tt0988824', '31910', utils.fanart_shippuden)

	#if section == 'episodios_dub_fonte3':
	#	list_episodes(meuanime_io.get_links_shippuden_dub, info.pular_shippuden, info.nao_pular_shippuden, 'tt0988824', '31910', utils.fanart_shippuden)	

	if section == 'episodios_leg_fonte1':
		list_episodes(animeq_blog.get_links_shippuden_leg, info.pular_shippuden, info.nao_pular_shippuden, 'tt0988824', '31910', utils.fanart_shippuden)	
	
	if section == 'episodios_leg_fonte2':
		list_episodes(dattebane_com.get_links_shippuden_leg, info.pular_shippuden, info.nao_pular_shippuden, 'tt0988824', '31910', utils.fanart_shippuden)

	if section == 'filmes':
		for item in torrent.filmes_shippuden:
			utils.createItem('plugin://plugin.video.elementum/play?uri=' + item[1], item[0], imdb = 'tt0988824', tmdb = '31910', fanart = utils.fanart_shippuden)

	if section == 'ovas':
		for item in dattebane_com.get_links_ovas():
			utils.createItem(item['link'], item['name'], imdb = 'tt0988824', tmdb = '31910', fanart = utils.fanart_shippuden, image = item['image'])

	utils.endDirectory()


if __name__ == '__main__':
	utils.plugin = plugin
	utils.log('init')
	plugin.run()
