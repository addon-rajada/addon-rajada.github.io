## Year Explorer

- Explore filmes e séries de acordo com ano de lançamento
- Busca de conteúdo similar através do menu de contexto
- Compatível com Elementum

## ToDo


- index threadpool
- list seasons and eps

- try update current li with imdb

<reuselanguageinvoker>true</reuselanguageinvoker>