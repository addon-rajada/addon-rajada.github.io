cd ..
zip -r -u -9 -T plugin.video.year-explorer.zip plugin.video.year-explorer/ -x "plugin.video.year-explorer/.git/*"
