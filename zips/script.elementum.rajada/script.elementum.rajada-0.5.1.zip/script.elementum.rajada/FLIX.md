### Elementum <-> Flix

**Convert Elementum to Flix**

1. run `rename.flix.sh`
2. rename project folder to `script.flix.rajada`
3. run `generate.flix.sh`

**Convert Flix to Elementum**

1. run `rename.elementum.flix.sh`
2. rename project folder to `script.elementum.rajada`
3. run `generate.sh`
