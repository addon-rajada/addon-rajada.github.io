### Elementum <-> Jacktook

**Convert Elementum to Jacktook**

1. run `rename.jacktook.sh`
2. rename project folder to `script.jacktook.rajada`
3. run `generate.jacktook.sh`

**Convert Jacktook to Elementum**

1. run `rename.elementum.jacktook.sh`
2. rename project folder to `script.elementum.rajada`
3. run `generate.sh`
