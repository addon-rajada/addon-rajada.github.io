## Update Guide

### Add provider

1. add entry to providers.json
2. use check_provider scripts to assert provider is working
3. update settings.xml
4. add entry to readme.md of providers folder
