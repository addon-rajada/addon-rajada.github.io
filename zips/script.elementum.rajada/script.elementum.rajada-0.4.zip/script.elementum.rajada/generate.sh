cd ..
zip -r -u -9 -T script.elementum.rajada-0.4.zip script.elementum.rajada/ -x "script.elementum.rajada/.git/*" -x "*.pyc"
