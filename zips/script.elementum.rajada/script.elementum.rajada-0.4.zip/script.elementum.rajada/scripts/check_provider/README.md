## Providers Checking

This is a standalone project made with parser package to check all magnet links from a provider/all providers given a query.

Run using command line:
```sh
python main.py
```

Run using interface:

```sh
pip install PyQt5
python gui.py
```
