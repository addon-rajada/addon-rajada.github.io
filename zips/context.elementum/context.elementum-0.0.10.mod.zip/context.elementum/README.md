# Context Menu for Elementum

Add always visible play option.

**ToDo**

- play container item by it's name
