# Context Menu for Elementum

Add always visible play option.
