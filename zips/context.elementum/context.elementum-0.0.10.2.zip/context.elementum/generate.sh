cd ..
zip -r -u -9 -T context.elementum-0.0.10.2.zip context.elementum/ -x "context.elementum/.git/*"
