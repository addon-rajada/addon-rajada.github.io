# To Do

### Features

- comics by first letter
- remove plot references as Picture ListItem doesn't have it
- blogspot quality settings ?

### GUI

- portrait mode
- setting for sectors number ?
- use keys to navigate image instead controls ?
- zoom and rotate animations to image control ?

### Providers

- https://everythingmoe.com/
