## Providers

| url | type | language | last check | notes |
| -   | -    | -        | -          | -     |
| comicextra.me | comics | english | 26.02.24 ok | slow (timeout for search) |
| galaxiadosquadrinhos.com.br | comics | portuguese | 26.02.24 ok | some posts will point to external link; spam posts |
| mangadex.org | mangas | multi | 26.02.24 intermittent | - |
| mangananquim.com | mangas | portuguese | 26.02.24 ok | - |
| mangaonline.biz | mangas | portuguese | 26.02.24 ok | - |
| mangapill.com | mangas | english | 26.02.24 ok | cloudflare for images url (needs referer) |
| readcomics.top | comics | english | 26.02.24 ok | - |
| xoxocomic.com | comics | english | 26.02.24 ok | - |

