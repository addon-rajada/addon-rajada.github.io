
# Providers Info

| **Provider**            | **Search**                                    | **Ads** | **Last check**                | **Default**   |
|-------------------------|-----------------------------------------------|---------|-------------------------------|---------------|
| 4kfilmeshd.net          | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| baixartorrents.net      | search.php?q=QUERY                            | Y       | 22.05.23 - Ok                 | N (many ads)  |
| bludvfilmes.net         | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| cinetorrent.com.br      | search?q=QUERY                                | N       | 12.05.23 - Ok                 | Y             |
| comandohds.com          | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| comandotorrents.to      | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| comandotorrents3.com    | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| filmestorrent.tv        | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| filmestorrents.pro      | ?s=QUERY                                      | N       | 12.05.23 - Ok                 | Y             |
| filmeviatorrents.org    | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| insanostorrent.com      | ?s=QUERY                                      | N       | 12.05.23 - Ok                 | Y             |
| lapumia.org             | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| meufilmestorrenthd.net  | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| nerdfilmes.com.br       | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| netjmx.com              | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| playfilmetorrent.net    | ?s=QUERY                                      | ?       | 22.05.23 - Fail (maintenance) | Y             |
| supertorrents.net       | ?s=QUERY                                      | ?       | 22.05.23 - Fail (error 403)   | N (not added) |
| torrentdofilmes.com     | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| torrentdosfilmes.se     | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| torrentdosfilmes.site   | ?s=QUERY                                      | Y       | 22.05.23 - Ok                 | Y             |
| torrentdosfilmeshd1.net | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |
| torrentgalaxy.to        | torrents.php?search=QUERY [Dublado Portugues] | N       | 22.05.23 - Ok                 | Y             |
| wolverdonfilme.net      | ?s=QUERY                                      | Y       | 12.05.23 - Ok                 | Y             |

