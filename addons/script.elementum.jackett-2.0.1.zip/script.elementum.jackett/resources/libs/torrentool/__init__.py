VERSION = (1, 1, 1)

VERSION_STR = '.'.join(map(str, VERSION))
"""Application version number string."""